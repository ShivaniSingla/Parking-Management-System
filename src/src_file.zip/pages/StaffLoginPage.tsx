import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FaUserTie } from 'react-icons/fa';
import { useApp } from '../context/AppContext';
import { supabase } from '../lib/supabaseClient';
import '../styles/LoginPage.css';

const StaffLoginPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useApp();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const { data, error: signInError } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password,
      });

      if (signInError) throw signInError;

      if (data.user) {
        // Fetch profile to verify role
        const { data: profile, error: profileError } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', data.user.id)
          .single();

        let userRole = profile?.role;
        if (!profile || profileError?.code === 'PGRST116') {
            userRole = 'staff'; // default to staff for older accounts
        }

        if (userRole === 'staff' || userRole === 'admin') {
            login({ username: data.user.email || 'user', role: userRole });
            navigate('/dashboard');
        } else {
            // Not a staff, logout
            await supabase.auth.signOut();
            setError("Unauthorized account access.");
        }
      }
    } catch (err: any) {
      setError(err.message || 'Failed to sign in');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <div className="login-card">
        <div className="login-logo" style={{ backgroundColor: 'var(--success)', color: 'white' }}>
          <FaUserTie />
        </div>
        <h1 className="login-title">Staff Login</h1>
        <p className="login-subtitle">Sign in to manage parking vehicles</p>

        {error && <div className="login-error">{error}</div>}

        <form className="login-form" onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Email</label>
            <input 
              type="email" 
              className="form-input" 
              value={email}
              onChange={e => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label>Password</label>
            <input 
              type="password" 
              className="form-input" 
              value={password}
              onChange={e => setPassword(e.target.value)}
              required
            />
          </div>
          <button type="submit" className="btn btn-primary" style={{ backgroundColor: 'var(--success)' }} disabled={loading}>
            {loading ? 'Signing in...' : 'Sign In as Staff'}
          </button>
          
          <button 
            type="button" 
            className="btn btn-outline" 
            style={{ marginTop: '1rem', width: '100%', padding: '0.75rem', backgroundColor: 'transparent', border: 'none', textDecoration: 'underline' }}
            onClick={() => navigate('/')}
          >
            Go Back
          </button>
        </form>
      </div>
    </div>
  );
};

export default StaffLoginPage;
